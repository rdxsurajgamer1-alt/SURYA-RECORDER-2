# SURYA RECORDER — Android starter

This project is uploaded as a ZIP. The GitHub Actions workflow extracts it automatically; you do not need to extract it on your phone.

## Included in this build
- 720p / 1080p / 2K (1440p) / 4K (2160p) resolution choices
- 30 / 60 / 90 FPS requested encoder settings
- Android MediaProjection full-screen capture
- Microphone audio
- Floating SURYA bubble with Pause/Resume and Stop controls
- Saves MP4 to Gallery > Movies > SURYA RECORDER
- Custom SURYA app icon

## Important limitations
- Internal/game audio capture is NOT implemented in this version. Android playback capture has app/game opt-in and device restrictions; it needs a separate audio-capture and muxing implementation.
- The floating control currently opens Pause/Resume and Stop only. It does not yet offer a movable custom capture-region selector or aspect-ratio presets.
- 2K/4K and 60/90 FPS are requested settings, not guaranteed output. The phone encoder/display may reject unsupported combinations or reduce performance.
- This project has not been compiled and tested on a physical phone in this environment. Treat the APK as a test build, not a verified release.
