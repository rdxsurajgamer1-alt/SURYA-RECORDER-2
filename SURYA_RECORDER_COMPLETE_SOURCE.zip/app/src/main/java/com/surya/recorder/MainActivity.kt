package com.surya.recorder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var quality: Spinner
    private lateinit var frameRate: Spinner
    private lateinit var status: TextView
    private val captureRequest = 704

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        askPermissions()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 24)
            setBackgroundColor(Color.rgb(16,19,27))
        }
        fun text(value: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 12, 0, 8)
        }
        root.addView(text("SURYA RECORDER", 28f, true))
        root.addView(text("SCREEN + GAMING RECORDER", 13f, true))
        root.addView(text("Video resolution", 16f, true))
        quality = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("720p", "1080p", "2K (1440p)", "4K (2160p)"))
        }
        root.addView(quality, LinearLayout.LayoutParams(-1, 54))
        root.addView(text("Frame rate", 16f, true))
        frameRate = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("30 FPS", "60 FPS", "90 FPS"))
        }
        root.addView(frameRate, LinearLayout.LayoutParams(-1, 54))
        root.addView(text("Audio", 16f, true))
        root.addView(text("Microphone: ON  |  Internal game audio: Android/game support required; not enabled in this build.", 13f))
        val start = Button(this).apply {
            text = "START RECORDING"
            setOnClickListener { startCaptureFlow() }
        }
        root.addView(start, LinearLayout.LayoutParams(-1, 56))
        val stop = Button(this).apply {
            text = "STOP RECORDING"
            setOnClickListener { startService(Intent(this@MainActivity, RecordingService::class.java).setAction(RecordingService.STOP)) }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1, 56))
        status = text("Videos are saved to your Gallery in the Movies/SURYA RECORDER folder.", 13f)
        root.addView(status)
        root.addView(text("Note: resolution/FPS depend on phone encoder and display. Floating controls require 'Display over other apps' permission. This starter records the full screen.", 12f))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun askPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 801)
    }

    private fun startCaptureFlow() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Allow microphone permission first."
            askPermissions()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow Display over other apps, then return and tap Start."
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val height = when (quality.selectedItemPosition) { 0 -> 720; 1 -> 1080; 2 -> 1440; else -> 2160 }
            val fps = listOf(30,60,90)[frameRate.selectedItemPosition]
            val service = Intent(this, RecordingService::class.java).apply {
                action = RecordingService.START
                putExtra(RecordingService.CODE, resultCode)
                putExtra(RecordingService.DATA, data)
                putExtra(RecordingService.HEIGHT, height)
                putExtra(RecordingService.FPS, fps)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "Recording started. Use the floating SURYA control to pause/resume or stop."
        } else status.text = "Screen capture permission was cancelled."
    }
}
