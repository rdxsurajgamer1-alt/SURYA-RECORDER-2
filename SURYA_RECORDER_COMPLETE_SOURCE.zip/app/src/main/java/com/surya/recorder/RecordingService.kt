package com.surya.recorder

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.view.*
import android.widget.*
import android.content.ContentValues
import java.text.SimpleDateFormat
import java.util.*

class RecordingService : Service() {
    companion object {
        const val START = "surya.START"
        const val STOP = "surya.STOP"
        const val PAUSE = "surya.PAUSE"
        const val RESUME = "surya.RESUME"
        const val CODE = "resultCode"
        const val DATA = "data"
        const val HEIGHT = "height"
        const val FPS = "fps"
        private const val CHANNEL = "surya_recording"
        private const val ID = 91
    }
    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlay: View? = null
    private var windowManager: WindowManager? = null
    private var videoUri: android.net.Uri? = null
    private var paused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> startCapture(intent)
            STOP -> stopCapture()
            PAUSE -> pauseCapture()
            RESUME -> resumeCapture()
        }
        return START_NOT_STICKY
    }

    private fun makeNotification(msg: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "SURYA recording", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("SURYA RECORDER").setContentText(msg)
            .setSmallIcon(android.R.drawable.presence_video_online).setOngoing(true).build()
    }

    private fun startCapture(intent: Intent) {
        startForeground(ID, makeNotification("Starting screen recording…"))
        try {
            val code = intent.getIntExtra(CODE, Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val consent = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(DATA, Intent::class.java) else intent.getParcelableExtra(DATA) as? Intent
            require(code == Activity.RESULT_OK && consent != null) { "Screen permission missing" }

            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            val targetH = intent.getIntExtra(HEIGHT, 1080)
            val fps = intent.getIntExtra(FPS, 30).coerceIn(15,90)
            val outW = ((targetH.toFloat() * metrics.widthPixels / metrics.heightPixels).toInt() / 2) * 2
            val outH = targetH - (targetH % 2)

            val name = "SURYA_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SURYA RECORDER")
            }
            videoUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            val pfd = contentResolver.openFileDescriptor(videoUri!!, "w") ?: error("Cannot create video file")
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder = mr
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(pfd.fileDescriptor)
            mr.setVideoSize(outW, outH)
            mr.setVideoFrameRate(fps)
            mr.setVideoEncodingBitRate((outW.toLong()*outH*fps*0.12).toLong().coerceIn(2_000_000L,80_000_000L).toInt())
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioEncodingBitRate(128000)
            mr.setAudioSamplingRate(44100)
            mr.prepare()
            projection = (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, consent!!)
            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, null)
            virtualDisplay = projection!!.createVirtualDisplay("SURYA", outW, outH, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mr.surface, null, null)
            mr.start()
            showFloatingControls()
            getSystemService(NotificationManager::class.java).notify(ID, makeNotification("Recording • $fps FPS • ${targetH}p"))
        } catch (e: Exception) {
            try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
            recorder = null
            videoUri?.let { contentResolver.delete(it, null, null) }
            videoUri = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun showFloatingControls() {
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10,10,10,10)
                setBackgroundColor(0xEE17212B.toInt())
            }
            val bubble = Button(this).apply {
                text = "SURYA ●"
                setOnClickListener {
                    if (panel.childCount == 1) {
                        panel.addView(Button(this@RecordingService).apply { text = if (paused) "RESUME" else "PAUSE"; setOnClickListener { if (paused) resumeCapture() else pauseCapture(); (this as Button).text = if (paused) "RESUME" else "PAUSE" } })
                        panel.addView(Button(this@RecordingService).apply { text = "STOP"; setOnClickListener { stopCapture() } })
                    } else {
                        while (panel.childCount > 1) panel.removeViewAt(1)
                    }
                }
            }
            panel.addView(bubble)
            overlay = panel
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 180 }
            windowManager?.addView(panel, params)
        } catch (_: Exception) {}
    }

    private fun pauseCapture() {
        if (Build.VERSION.SDK_INT >= 24) try { recorder?.pause(); paused = true } catch (_: Exception) {}
    }
    private fun resumeCapture() {
        if (Build.VERSION.SDK_INT >= 24) try { recorder?.resume(); paused = false } catch (_: Exception) {}
    }

    private fun stopCapture() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        overlay = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        videoUri?.let {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                try { contentResolver.update(it, values, null, null) } catch (_: Exception) {}
            }
        }
        videoUri = null
        paused = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
}
