package com.suryarecorder
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
class CaptureActivity:Activity(){
 private val req=901
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val m=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  startActivityForResult(m.createScreenCaptureIntent(),req)
 }
 @Deprecated("Activity result API kept for compatibility")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==req&&resultCode==RESULT_OK&&data!=null){
   val i=Intent(this,RecordingService::class.java).apply{
    action=RecordingService.ACTION_START;putExtra(RecordingService.EXTRA_RESULT_CODE,resultCode);putExtra(RecordingService.EXTRA_DATA,data)
    for(k in listOf("ratio","res","fps","audio","cw","ch"))putExtra(k,intent.getStringExtra(k))
   };startForegroundService(i);Toast.makeText(this,"Recording शुरू हो रही है",Toast.LENGTH_SHORT).show()
  };finish()
 }
}
