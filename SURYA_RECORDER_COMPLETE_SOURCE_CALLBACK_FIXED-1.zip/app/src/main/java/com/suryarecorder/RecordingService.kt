package com.suryarecorder
import android.app.*
import android.content.*
import android.hardware.display.*
import android.media.MediaRecorder
import android.media.projection.*
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.io.File
class RecordingService:Service(){
 companion object{
  const val ACTION_START="com.suryarecorder.START";const val ACTION_STOP="com.suryarecorder.STOP"
  const val EXTRA_RESULT_CODE="result_code";const val EXTRA_DATA="projection_data"
  const val CHANNEL="surya_recording"
 }
 private var rec:MediaRecorder?=null;private var proj:MediaProjection?=null;private var vd:VirtualDisplay?=null
 private var projectionCallback:MediaProjection.Callback?=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_STOP){stopRec();return START_NOT_STICKY}
  if(i?.action==ACTION_START){channel();startForeground(41,notification());record(i)}
  return START_NOT_STICKY
 }
 private fun record(i:Intent){
  try{
   val code=i.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)
   val data=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(EXTRA_DATA,Intent::class.java) else { @Suppress("DEPRECATION") i.getParcelableExtra(EXTRA_DATA) } ?: error("Permission data missing")
   proj=(getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
   // Android 14+ requires a callback to be registered before createVirtualDisplay().
   projectionCallback=object:MediaProjection.Callback(){
    override fun onStop(){ stopRec() }
   }
   proj?.registerCallback(projectionCallback!!, Handler(Looper.getMainLooper()))
   val dm=DisplayMetrics();@Suppress("DEPRECATION")(getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
   val resolution=i.getStringExtra("res")?.toIntOrNull()?:1080;val ratio=i.getStringExtra("ratio")?:"9:16"
   var rw=dm.widthPixels.toFloat();var rh=dm.heightPixels.toFloat()
   when(ratio){"9:16"->{rw=9f;rh=16f};"16:9"->{rw=16f;rh=9f};"1:1"->{rw=1f;rh=1f};"4:3"->{rw=4f;rh=3f};"Custom"->{rw=i.getStringExtra("cw")?.toFloatOrNull()?:1080f;rh=i.getStringExtra("ch")?.toFloatOrNull()?:1920f}}
   val landscape=dm.widthPixels>dm.heightPixels
   val w=if(landscape)resolution else (resolution*rw/rh).toInt()
   val h=if(landscape)(resolution*rh/rw).toInt() else resolution
   val ow=(w.coerceAtLeast(2)/2)*2;val oh=(h.coerceAtLeast(2)/2)*2
   val fps=(i.getStringExtra("fps")?.toIntOrNull()?:30).coerceIn(15,90);val audio=i.getStringExtra("audio")?:"MIC"
   val dir=File(getExternalFilesDir(Environment.DIRECTORY_MOVIES),"SURYA_RECORDER");dir.mkdirs()
   val file=File(dir,"SURYA_${System.currentTimeMillis()}.mp4")
   val r=if(Build.VERSION.SDK_INT>=31)MediaRecorder(this) else MediaRecorder();rec=r
   r.setVideoSource(MediaRecorder.VideoSource.SURFACE);r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
   r.setVideoEncoder(MediaRecorder.VideoEncoder.H264);r.setVideoSize(ow,oh);r.setVideoFrameRate(fps)
   r.setVideoEncodingBitRate(if(resolution>=2160)20000000 else if(resolution>=1440)12000000 else 8000000)
   if(audio=="MIC"){r.setAudioSource(MediaRecorder.AudioSource.MIC);r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);r.setAudioEncodingBitRate(128000);r.setAudioSamplingRate(44100)}
   r.setOutputFile(file.absolutePath);r.prepare()
   vd=proj?.createVirtualDisplay("SURYA",ow,oh,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,r.surface,null,null)
   r.start()
   if(audio=="INTERNAL"||audio=="BOTH")Toast.makeText(this,"ध्यान दें: Internal Audio इस prototype में अभी उपलब्ध नहीं है।",Toast.LENGTH_LONG).show()
  }catch(e:Exception){Toast.makeText(this,"Recording शुरू नहीं हुई: ${e.message}",Toast.LENGTH_LONG).show();stopRec()}
 }
 private fun stopRec(){try{rec?.stop()}catch(e:Exception){};try{rec?.release()}catch(e:Exception){};rec=null
  try{vd?.release()}catch(e:Exception){};vd=null
  try{projectionCallback?.let{proj?.unregisterCallback(it)}}catch(e:Exception){};projectionCallback=null
  try{proj?.stop()}catch(e:Exception){};proj=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"SURYA Recording",NotificationManager.IMPORTANCE_LOW))}
 private fun notification():Notification{
  val si=Intent(this,RecordingService::class.java).setAction(ACTION_STOP)
  val pi=PendingIntent.getService(this,0,si,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  return Notification.Builder(this,CHANNEL).setContentTitle("SURYA RECORDER").setContentText("Recording चालू है").setSmallIcon(android.R.drawable.presence_video_online).addAction(Notification.Action.Builder(null,"Stop",pi).build()).setOngoing(true).build()
 }
 override fun onBind(i:Intent?):IBinder?=null
 override fun onDestroy(){try{rec?.release()}catch(e:Exception){};try{vd?.release()}catch(e:Exception){};try{proj?.stop()}catch(e:Exception){};super.onDestroy()}
}
